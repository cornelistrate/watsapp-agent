exports.transcribe = async (mediaId) => {
  // TODO: download media from WhatsApp and use a speech-to-text service
  console.log('Stub STT for mediaId', mediaId);
  return 'voice message transcription';
};

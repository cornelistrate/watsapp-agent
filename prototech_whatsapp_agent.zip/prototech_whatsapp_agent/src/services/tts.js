exports.speak = async (text) => {
  // TODO: integrate a text-to-speech service to return audio file URL
  console.log('Stub TTS for text', text);
  return null;
};
